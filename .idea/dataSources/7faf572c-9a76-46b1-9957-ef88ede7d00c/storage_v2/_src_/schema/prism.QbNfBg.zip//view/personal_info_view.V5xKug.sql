create definer = root@localhost view personal_info_view as
select `pi`.`p_id`                                AS `p_id`,
       concat(`pi`.`l_name`, ', ', `pi`.`f_name`) AS `full_name`,
       `rs`.`sex_desc`                            AS `sex_desc`,
       `eb`.`school`                              AS `school`,
       `gi`.`issued_id`                           AS `issued_id`
from (((`prism`.`personal_info` `pi` join `prism`.`ref_sex` `rs`
        on ((`pi`.`sex_id` = `rs`.`sex_id`))) join `prism`.`educ_background` `eb`
       on ((`pi`.`p_id` = `eb`.`p_id`))) join `prism`.`govt_issued_id` `gi` on ((`pi`.`p_id` = `gi`.`p_id`)));

